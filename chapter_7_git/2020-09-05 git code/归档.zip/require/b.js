define({
    info:"b。js"
});