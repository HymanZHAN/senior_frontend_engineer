export default class Skin301120 {
  constructor() {
    this.name = "原画";
    this.src = "./sources/skins/301120.png";
    this.ico = "./sources/heros/luban1.png"
  }
}
