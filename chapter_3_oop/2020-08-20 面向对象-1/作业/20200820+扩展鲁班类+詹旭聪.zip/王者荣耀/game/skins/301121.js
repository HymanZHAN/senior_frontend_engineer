export default class Skin301121 {
  constructor() {
    this.name = "木偶奇遇记";
    this.src = "./sources/skins/301121.png";
    this.ico = "./sources/heros/luban2.png";
  }
}
