export default class Skin301660 {
  constructor() {
    this.name = "原画";
    this.ico = "./sources/heros/yase1.png"
    this.src = "./sources/skins/301660.png";
  }
}
