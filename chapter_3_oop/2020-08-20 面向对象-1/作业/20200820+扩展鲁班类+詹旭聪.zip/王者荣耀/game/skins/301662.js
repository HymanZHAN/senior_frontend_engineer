export default class Skin301662 {
  constructor() {
    this.name = "狮心王";
    this.ico = "./sources/heros/yase3.png"
    this.src = "./sources/skins/301662.png";
  }
}
