export default class Skin301122 {
  constructor() {
    this.name = "福禄兄弟";
    this.src = "./sources/skins/301122.png";
    this.ico = "./sources/heros/luban3.png";
  }
}
