export default class Skin301661 {
  constructor() {
    this.name = "死亡骑士";
    this.ico = "./sources/heros/yase2.png";

    this.src = "./sources/skins/301661.png";
  }
}
