// 技能对象服务的；---》抽象；  技能类；
export default class S11230 {
  constructor() {
    this.name = "空中支援";
    this.ico = "./sources/skills/11230.png";
  }
}