export default class S11220 {
  constructor() {
    this.name = "无敌鲨嘴炮";
    this.ico = "./sources/skills/11220.png";
  }
}
