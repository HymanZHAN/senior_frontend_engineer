export default class S16610{
    constructor(){
        this.name = "誓约之盾";
        this.ico = "./sources/skills/16610.png";
    }
}