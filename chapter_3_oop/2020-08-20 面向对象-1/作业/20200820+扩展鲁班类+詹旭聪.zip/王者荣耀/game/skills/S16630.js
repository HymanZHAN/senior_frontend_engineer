// 技能对象服务的；---》抽象；  技能类；
export default class S16630{
    constructor(){
        this.name = "圣剑裁决";
        this.ico = "./sources/skills/16630.png";
    }
}