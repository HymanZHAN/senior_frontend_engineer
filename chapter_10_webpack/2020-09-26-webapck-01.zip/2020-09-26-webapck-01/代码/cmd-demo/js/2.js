define(function() {
    function fn() {
        console.log('fn');
    }

    return {
        fn
    }
});