define(['./js/2.js'], function(m2) {
    // './2.js' => document.createElement('script')

    console.log(m2);
})