function fn() {
    console.log('fn');
    fn2();
}

function fn1() {
    console.log('fn1');
}