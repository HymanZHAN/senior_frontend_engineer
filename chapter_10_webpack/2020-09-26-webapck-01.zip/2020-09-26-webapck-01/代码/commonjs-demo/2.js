let a = 100;

module.exports = {
    v1: a
}