const m2 = require('./2.js');
console.log(module);
const axios = require('./axios');
const kkb = require('kkb');

console.log(m2, axios, kkb);