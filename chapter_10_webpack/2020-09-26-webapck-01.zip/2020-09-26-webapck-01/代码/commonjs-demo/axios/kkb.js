const libs = require('./libs');

module.exports = {
    axios: function() {
        libs.getUrl();
    }
}