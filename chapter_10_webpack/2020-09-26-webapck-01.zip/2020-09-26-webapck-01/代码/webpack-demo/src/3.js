import m2 from './2.js';

m2.fn();