export default {
    fn() {
        console.log('fn');
    }
}