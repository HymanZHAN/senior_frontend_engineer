//暗号：无敌凯爷

import TodoList from "./todo-list";

function App() {
  return <TodoList />;
}

export default App;
