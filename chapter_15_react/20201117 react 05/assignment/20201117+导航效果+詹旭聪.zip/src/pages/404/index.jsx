function Page404() {
  return <h1>页面飞走了</h1>;
}
export default Page404;
