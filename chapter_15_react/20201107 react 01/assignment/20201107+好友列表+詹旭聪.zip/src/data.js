export const data = [
  {
    groupName: "家人",
    members: ["爸爸", "妈妈"],
  },
  {
    groupName: "朋友",
    members: ["张三", "李四", "王五"],
  },

  {
    groupName: "客户",
    members: ["阿里", "腾讯", "头条"],
  },
];
